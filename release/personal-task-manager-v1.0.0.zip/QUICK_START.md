# Personal Task Manager v1.0.0 - Quick Start 
 
## Installation 
1. Run install.bat 
2. Configure .env file 
3. Run: npm start 
4. Run: npm run electron 
